import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SignUP } from '../model/signup.model';

@Injectable({
  providedIn: 'root'
})
export class SignUpService {

  constructor(private http:HttpClient) { }
baseUrl:string='http://localhost:8099';



createSignUp(user:SignUP){
  return this.http.post(this.baseUrl+"/signup",user);
}

}
