import { SignUpService } from './../../services/signup.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { SignUP } from '../../model/signup.model';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private signupservice: SignUpService, private formbuilder: FormBuilder) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      cname: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
      customer: ['', Validators.required]
    })
  }

  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    console.log(this.addForm.value);
    this.signupservice.createSignUp(this.addForm.value) 
    .subscribe(data=>{
      alert(this.addForm.controls.cname.value+' recors added successfully..!!');
    })
    alert("user is registered and ready to signIn")
  }
}

