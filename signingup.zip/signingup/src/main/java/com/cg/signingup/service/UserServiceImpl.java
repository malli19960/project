package com.cg.signingup.service;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.signingup.entities.User;
import com.cg.signingup.repository.UserDAO;
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired UserDAO dao;
@Transactional
	public void create(User c) {
		// TODO Auto-generated method stub
dao.save(c);
	}

}
