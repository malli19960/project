package com.cg.signingup.service;

import com.cg.signingup.entities.User;

public interface UserService {

	void create(User c);
}
