package com.cg.signingup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.signingup.entities.User;
import com.cg.signingup.service.UserService;

@RestController
@CrossOrigin(allowedHeaders="*", origins="*")
public class UserController {

	@Autowired UserService service;
	
	@PostMapping(value = "/signup", consumes = { "application/json","application/xml"})
	public ResponseEntity<String> signup(@RequestBody User user) {
		System.out.println("Create");
		service.create(user);
		return new ResponseEntity<String>("signed up successfully", HttpStatus.CREATED);
}
	
	
}
