package com.cg.signingup.entities;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class User {
     @Id
     @Column(name="email")
     private String email;
     @Column(name="cname")
	 private String cname;
	@Column(name="passowrd")
	 private String password;
	@Column(name="customer")
	 private String customer;
	
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	
	 public User() {
		 
	 
}
	public User(String email, String cname, String password, String customer) {
		super();
		this.email = email;
		this.cname = cname;
		this.password = password;
		this.customer = customer;
	}}
