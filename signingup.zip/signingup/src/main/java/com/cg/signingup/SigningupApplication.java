package com.cg.signingup;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SigningupApplication {

	public static void main(String[] args) {
		SpringApplication.run(SigningupApplication.class, args);
	}

}
